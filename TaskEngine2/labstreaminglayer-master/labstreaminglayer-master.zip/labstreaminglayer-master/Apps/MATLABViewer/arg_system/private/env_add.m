hlp_matlab_version >= 706
