//---------------------------------------------------------------------------
#include<vcl.h>
#pragma hdrstop



#include "math_util.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)

//Template definitions must be in header file, per C++ compiler requirements
