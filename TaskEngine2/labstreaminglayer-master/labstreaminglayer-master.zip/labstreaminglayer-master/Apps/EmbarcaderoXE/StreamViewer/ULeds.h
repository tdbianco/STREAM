//---------------------------------------------------------------------------

#ifndef ULedsH
#define ULedsH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TFormLEDs : public TForm
{
__published:	// IDE-managed Components
	TPanel *Panel1;
	TCheckBox *CheckBox1;
	TCheckBox *CheckBox2;
	TCheckBox *CheckBox3;
	TCheckBox *CheckBox4;
	TCheckBox *CheckBox5;
	TCheckBox *CheckBox6;
	TCheckBox *CheckBox7;
	TCheckBox *CheckBox8;
	TCheckBox *CheckBox9;
	TCheckBox *CheckBox10;
	TCheckBox *CheckBox11;
	TCheckBox *CheckBox12;
	TCheckBox *CheckBox13;
	TCheckBox *CheckBox14;
	TCheckBox *CheckBox15;
	TCheckBox *CheckBox16;
	TCheckBox *CheckBox17;
	TCheckBox *CheckBox18;
	TCheckBox *CheckBox19;
	TCheckBox *CheckBox20;
	TCheckBox *CheckBox21;
	TCheckBox *CheckBox22;
	TCheckBox *CheckBox23;
	TCheckBox *CheckBox24;
	TCheckBox *CheckBox25;
	TCheckBox *CheckBox26;
	TCheckBox *CheckBox27;
	TCheckBox *CheckBox28;
	TCheckBox *CheckBox29;
	TCheckBox *CheckBox30;
	TCheckBox *CheckBox31;
	TCheckBox *CheckBox32;
	TCheckBox *CheckBox33;
	TCheckBox *CheckBox34;
	TCheckBox *CheckBox35;
	TCheckBox *CheckBox36;
	TCheckBox *CheckBox37;
	TCheckBox *CheckBox38;
	TCheckBox *CheckBox39;
	TCheckBox *CheckBox40;
	TCheckBox *CheckBox41;
	TCheckBox *CheckBox42;
	TCheckBox *CheckBox43;
	TCheckBox *CheckBox44;
	TCheckBox *CheckBox45;
	TCheckBox *CheckBox46;
	TCheckBox *CheckBox47;
	TCheckBox *CheckBox48;
	TCheckBox *CheckBox49;
	TCheckBox *CheckBox50;
	TCheckBox *CheckBox51;
	TCheckBox *CheckBox52;
	TCheckBox *CheckBox53;
	TCheckBox *CheckBox54;
	TCheckBox *CheckBox55;
	TCheckBox *CheckBox56;
	TCheckBox *CheckBox57;
	TCheckBox *CheckBox58;
	TCheckBox *CheckBox59;
	TCheckBox *CheckBox60;
	TCheckBox *CheckBox61;
	TCheckBox *CheckBox62;
	TCheckBox *CheckBox63;
	TCheckBox *CheckBox64;
	TCheckBox *CheckBox65;
	TCheckBox *CheckBox66;
	TCheckBox *CheckBox67;
	TCheckBox *CheckBox68;
	TCheckBox *CheckBox69;
	TCheckBox *CheckBox70;
	TCheckBox *CheckBox71;
	TCheckBox *CheckBox72;
	TCheckBox *CheckBox73;
	TCheckBox *CheckBox74;
	TCheckBox *CheckBox75;
	TCheckBox *CheckBox76;
	TCheckBox *CheckBox77;
	TCheckBox *CheckBox78;
	TCheckBox *CheckBox79;
	TCheckBox *CheckBox80;
	TCheckBox *CheckBox81;
	TCheckBox *CheckBox82;
	TCheckBox *CheckBox83;
	TCheckBox *CheckBox84;
	TCheckBox *CheckBox85;
	TCheckBox *CheckBox86;
	TCheckBox *CheckBox87;
	TCheckBox *CheckBox88;
	TCheckBox *CheckBox89;
	TCheckBox *CheckBox90;
	TCheckBox *CheckBox91;
	TCheckBox *CheckBox92;
	TCheckBox *CheckBox93;
	TCheckBox *CheckBox94;
	TCheckBox *CheckBox95;
	TCheckBox *CheckBox96;
	TCheckBox *CheckBox97;
	TCheckBox *CheckBox98;
	TCheckBox *CheckBox99;
	TCheckBox *CheckBox100;
	TCheckBox *CheckBox101;
	TCheckBox *CheckBox102;
	TCheckBox *CheckBox103;
	TCheckBox *CheckBox104;
	TCheckBox *CheckBox105;
	TCheckBox *CheckBox106;
	TCheckBox *CheckBox107;
	TCheckBox *CheckBox108;
	TCheckBox *CheckBox109;
	TCheckBox *CheckBox110;
	TCheckBox *CheckBox111;
	TCheckBox *CheckBox112;
	TCheckBox *CheckBox113;
	TCheckBox *CheckBox114;
	TCheckBox *CheckBox115;
	TCheckBox *CheckBox116;
	TCheckBox *CheckBox117;
	TCheckBox *CheckBox118;
	TCheckBox *CheckBox119;
	TCheckBox *CheckBox120;
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall FormDeactivate(TObject *Sender);
private:	// User declarations
public:		// User declarations
	TCheckBox *CheckBoxLED[120];
	__fastcall TFormLEDs(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFormLEDs *FormLEDs;
//---------------------------------------------------------------------------
#endif
